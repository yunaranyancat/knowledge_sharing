# How To Implement Two-Factor Authentication With PyOTP and Google Authenticator in Your Flask App

Read the tutorial here: https://www.freecodecamp.org/news/how-to-implement-two-factor-authentication-in-your-flask-app/

Demo Video: https://www.youtube.com/watch?v=qzLcbq5-UNA
