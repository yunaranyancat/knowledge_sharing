<?php
$uploadFolder = 'videos/';
$allowedExtensions = array('webm', 'mp4', 'mov');

// Ensure the folder exists
if (!is_dir($uploadFolder)) {
    echo "No videos found.";
    exit;
}

// Get all video files from the folder with the allowed extensions
$videoFiles = array_filter(scandir($uploadFolder), function($file) use ($uploadFolder, $allowedExtensions) {
    $filePath = $uploadFolder . $file;
    $fileExtension = pathinfo($filePath, PATHINFO_EXTENSION);
    return in_array($fileExtension, $allowedExtensions);
});

if (empty($videoFiles)) {
    echo "No videos found.";
} else {
    echo '<h1>MANGSA SCAM</h1>';
    echo '<div class="video-container">';
    
    foreach ($videoFiles as $videoFile) {
        $videoPath = $uploadFolder . $videoFile;

        // Display the video with autoplay, loop, and muted attributes
        echo '<video class="video-item" autoplay loop muted>';
        echo '<source src="' . $videoPath . '" type="video/' . pathinfo($videoPath, PATHINFO_EXTENSION) . '">';
        echo 'Your browser does not support the video tag.';
        echo '</video>';
    }

    echo '</div>';
}
?>

<style>
    body {
        background-color: black; /* Dark background */
        color: #00ff00; /* Green text */
        font-family: 'Courier New', Courier, monospace; /* Monospace font for a digital look */
        text-align: center; /* Center align text */
        overflow-y: auto; /* Allow vertical scrolling */
        height: 100vh; /* Full viewport height */
        margin: 0; /* Remove default margin */
    }

    h1 {
        text-shadow: 0 0 20px #00ff00; /* Glowing text effect */
        margin-bottom: 20px; /* Space below the heading */
    }

    .video-container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center; /* Center align the videos */
        gap: 10px; /* Space between videos */
        padding: 20px; /* Add padding around the videos */
        overflow-y: auto; /* Allow vertical scrolling for the container */
    }

    .video-item {
        width: 320px; /* Fixed width */
        height: 240px; /* Fixed height */
        border: 2px solid #00ff00; /* Green border */
        border-radius: 8px; /* Rounded corners */
        box-shadow: 0 0 20px rgba(0, 255, 0, 0.5); /* Glowing shadow */
        transition: transform 0.2s; /* Smooth scaling effect */
    }

    .video-item:hover {
        transform: scale(1.05); /* Slightly enlarge video on hover */
    }
</style>
